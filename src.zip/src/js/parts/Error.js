var React = require('react');

module.exports = React.createClass({
    getDefaultProps(){
        return {
            message: 
        };
    },
    render() {
        return <div className="newslist-error">
            <p>{this.props.message}</p>
        </div>;
    }
});