var React = require('react');

module.exports = React.createClass({
    render() {
        return <div className="newslist-loading">
            <p>...</p>
        </div>;
    }
});
