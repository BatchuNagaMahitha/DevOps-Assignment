module.exports = {
  // base_url: "http://localhost:8080/",
  base_url: "http://123.206.255.148",
  routes: {
    INDEX_RANK: "top/",
    TOP_RANK: "toprank",
    BANNER: "banner",
    VIDEO_INFO: "view/",
    VIDEO_URL: "video/",
    SORT_VIDEOS: "sort/",
    
    SEARCH: "search",
    SEARCH_BY_TYPE: "searchbytype",
    
  },
  index_sorts: [24, 33, 31, 20, 17, 36, 119],

  sort_tags: {
    
  }
};
